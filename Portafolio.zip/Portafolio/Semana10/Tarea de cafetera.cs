﻿namespace Tarea_de_cafetera
{
    using System;

    class Cafetera
    {
        private int codigo;
        private int capacidad;
        private int tazasDisponibles;
        private int tazasServidas;

        public Cafetera(int codigo, int capacidad)
        {
            this.codigo = codigo;
            this.capacidad = capacidad;
            this.tazasDisponibles = 0;
            this.tazasServidas = 0;
        }

        public void HacerCafe()
        {
            tazasDisponibles = capacidad;
            tazasServidas = 0;
            Console.WriteLine("Cafetera llena");
        }

        public void ServirTaza(int cantidad)
        {
            if (cantidad > tazasDisponibles)
            {
                Console.WriteLine("No hay suficientes tazas disponibles");
            }
            else
            {
                tazasDisponibles -= cantidad;
                tazasServidas += cantidad;
                Console.WriteLine("Se han servido {0} tazas", cantidad);
            }
        }

        public double ObtenerPorcentajeDisponibilidad()
        {
            return ((double)tazasDisponibles / capacidad) * 100;
        }

        public void MostrarEstado()
        {
            Console.WriteLine("Código: {0}", codigo);
            Console.WriteLine("Capacidad: {0} tazas", capacidad);
            Console.WriteLine("Porcentaje de disponibilidad: {0}%", ObtenerPorcentajeDisponibilidad());
            Console.WriteLine("Tazas servidas: {0}", tazasServidas);
        }
    }

}