﻿using System;

namespace PeliculaProgram
{
    enum Genero { ACCION, COMEDIA, DRAMA, SUSPENSO }

    class Pelicula
    {
        private string nombre;
        private int duracion;
        private Genero genero;
        private int anio;
        private double calificacion;

        public Pelicula(string nombre, int duracion, Genero genero, int anio)
        {
            this.nombre = nombre;
            this.duracion = duracion;
            this.genero = genero;
            this.anio = anio;
            this.calificacion = 0;
        }

        public void ImprimirInformacion()
        {
            Console.WriteLine($"Nombre: {nombre}");
            Console.WriteLine($"Duración: {duracion} minutos");
            Console.WriteLine($"Género: {genero}");
            Console.WriteLine($"Año: {anio}");
            Console.WriteLine($"Calificación: {calificacion}");
        }

        public bool EsPeliculaEpica()
        {
            return duracion >= 180;
        }

        public string ObtenerValoracion()
        {
            if (calificacion <= 2)
            {
                return "Valoración: muy mala";
            }
            else if (calificacion <= 5)
            {
                return "Valoración: mala";
            }
            else if (calificacion <= 7)
            {
                return "Valoración: regular";
            }
            else if (calificacion <= 8)
            {
                return "Valoración: buena";
            }
            else
            {
                return "Valoración: excelente";
            }
        }

        public bool EsSimilar(Pelicula otraPelicula)
        {
            return this.genero == otraPelicula.genero && this.calificacion == otraPelicula.calificacion;
        }

        public void SetCalificacion(double calificacion)
        {
            if (calificacion >= 0 && calificacion <= 10)
            {
                this.calificacion = calificacion;
            }
            else
            {
                Console.WriteLine("La calificación debe estar entre 0 y 10.");
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Pelicula pelicula1 = new Pelicula("Matrix", 136, Genero.ACCION, 1999);
            Pelicula pelicula2 = new Pelicula("Avengers: Endgame", 181, Genero.ACCION, 2019);

            pelicula1.SetCalificacion(8.3);
            pelicula2.SetCalificacion(9.2);

            pelicula1.ImprimirInformacion();
            Console.WriteLine($"Es película épica: {pelicula1.EsPeliculaEpica()}");
            Console.WriteLine(pelicula1.ObtenerValoracion());

            pelicula2.ImprimirInformacion();
            Console.WriteLine($"Es película épica: {pelicula2.EsPeliculaEpica()}");
            Console.WriteLine(pelicula2.ObtenerValoracion());

            Console.WriteLine($"Las películas son similares: {pelicula1.EsSimilar(pelicula2)}");
        }
    }
}
