﻿using System;

class Program
{
    static void Main(string[] args)
    {
        
        int billetes100, billetes50, billetes20, billetes10, billetes5, billetes1;
        int monedas50, monedas25, monedas10, monedas5, monedas1;
        double totalCaja;

        // Solicitar el número de billetes y monedas de cada denominación
        Console.Write("Ingrese el número de billetes de Q100: ");
        billetes100 = int.Parse(Console.ReadLine());

        Console.Write("Ingrese el número de billetes de Q50: ");
        billetes50 = int.Parse(Console.ReadLine());

        Console.Write("Ingrese el número de billetes de Q20: ");
        billetes20 = int.Parse(Console.ReadLine());

        Console.Write("Ingrese el número de billetes de Q10: ");
        billetes10 = int.Parse(Console.ReadLine());

        Console.Write("Ingrese el número de billetes de Q5: ");
        billetes5 = int.Parse(Console.ReadLine());

        Console.Write("Ingrese el número de billetes de Q1: ");
        billetes1 = int.Parse(Console.ReadLine());

        Console.Write("Ingrese el número de monedas de Q0.50: ");
        monedas50 = int.Parse(Console.ReadLine());

        Console.Write("Ingrese el número de monedas de Q0.25: ");
        monedas25 = int.Parse(Console.ReadLine());

        Console.Write("Ingrese el número de monedas de Q0.10: ");
        monedas10 = int.Parse(Console.ReadLine());

        Console.Write("Ingrese el número de monedas de Q0.05: ");
        monedas5 = int.Parse(Console.ReadLine());

        Console.Write("Ingrese el número de monedas de Q0.01: ");
        monedas1 = int.Parse(Console.ReadLine());

        // Calcular el total de la caja registradora
        totalCaja = billetes100 * 100.0 + billetes50 * 50.0 + billetes20 * 20.0 + billetes10 * 10.0 + billetes5 * 5.0 + billetes1 * 1.0
                  + monedas50 * 0.5 + monedas25 * 0.25 + monedas10 * 0.10 + monedas5 * 0.05 + monedas1 * 0.01;

        
        Console.WriteLine($"El total de la caja registradora es de: Q{totalCaja}");
    }
}
