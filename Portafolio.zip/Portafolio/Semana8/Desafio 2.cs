﻿using System;

class Program
{
    static void Main(string[] args)
    {
       
        int numEmpleados, totalPagado = 0;
        double sueldoHora = 25.0;

        // Solicitar el número de empleados
        Console.Write("Ingrese el número de empleados: ");
        numEmpleados = int.Parse(Console.ReadLine());

        // Calcular el sueldo de cada empleado y el total pagado
        for (int i = 1; i <= numEmpleados; i++)
        {
            int horasSemana = 0;

            // Solicitar las horas trabajadas en cada día de la semana
            for (int j = 1; j <= 7; j++)
            {
                Console.Write($"Ingrese las horas trabajadas del día {j} para el empleado {i}: ");
                horasSemana += int.Parse(Console.ReadLine());
            }

            // Calcular el sueldo semanal del empleado y agregarlo al total pagado
            double sueldoSemana = horasSemana * sueldoHora;
            totalPagado += (int)sueldoSemana;
            Console.WriteLine($"El sueldo semanal del empleado {i} es de: Q{sueldoSemana}");
        }

        // Imprimir el total pagado por la empresa
        Console.WriteLine($"La empresa pagó un total de: Q{totalPagado}");
    }
}