﻿using System;

class Program
{
    static void Main(string[] args)
    {
        // Variables
        int meses = 20;
        double totalPagado = 0, montoActual = 10;

        // Calcular el monto mensual y el total pagado
        for (int i = 1; i <= meses; i++)
        {
            Console.WriteLine($"Mes {i}: Q{montoActual}");
            totalPagado += montoActual;
            montoActual *= 2;
        }

        // Imprimir los resultados
        double pagoMensual = totalPagado / meses;
        Console.WriteLine($"El pago mensual es de: Q{pagoMensual}");
        Console.WriteLine($"El total pagado después de {meses} meses es de: Q{totalPagado}");
    }
}